# CONTEXTO — Cocora 3D · Taller de Modelos

Registro detallado de lo construido. **Fecha:** sesión actual · **Stack:** React 19 + Vite 7 + TypeScript + Tailwind v4 + Three.js 0.187 + React Three Fiber 9 + drei 10 + Zustand 5.

> **Nota de rutas:** el encargo menciona archivos de un juego multijugador (`client/js/player.js`, `shared/mapData.js`, `server/gameRoom.js`, Socket.IO…). Ese proyecto no existe en este repositorio: aquí vive una **aplicación de visor 3D en un solo `dist/index.html`** (sin servidor, sin red). Todo lo aplicable se ha implementado en la estructura real del proyecto (`src/three/**`, `src/components/**`, `src/store.ts`), y cada pilar indica dónde queda su equivalente.

---

## Pilar 1 — Modelo 3D detallado del personaje (`src/three/models/Character.tsx`)

Reconstrucción completa del `createDetailedAvatar` como **réplica cel-shaded** de la ilustración:

- **Proporciones 1,80 m** (1,91 m con sombrero): cadera en `y=0.98`, columna `+0.10`, cuello `+0.44`, cabeza `+0.10`, cráneo elipsoidal (r 0,117, escala 0,92/1,06/1,00), mandíbula, nuca/cabello, patillas y barba corta bajo el ala.
- **Anatomía estilizada:** hombros redondeados (deltoides), torso atlético con cintura, pecho y abdomen, muslos, rodillas esféricas, pantorrillas, **botas de montaña** con caña, puntera, tacón, suela marcada con treads y hebilla lateral.
- **Sombrero vueltiao:** ala perfilada con `LatheGeometry` (12 puntos de perfil con vuelco hacia arriba en los bordes) + corona abombada `LatheGeometry`; **texturas procedurales en `<canvas>`**: patrón geométrico radial en blanco/negro para el ala (`TEX.sombreroBrim`, concéntricos + zigzag de rombos) y cinta trenzada para la corona (`TEX.sombreroBand`) + **cinta oscura sólida** alrededor de la corona.
- **Ruana/poncho:** dos paneles `CylinderGeometry` (frente/espalda) con **aperturas laterales** (`thetaStart/thetaLength` con hueco de 0,34 rad) para que los brazos se muevan libres; **textura `<canvas>`** de lienzo crema con tejido fino y **franjas horizontales negras dobles/triples en el borde inferior** + **flecos** geométricos (74 hilos fusionados con `GeoBuilder`, omitidos en los huecos laterales). Caída hasta medio muslo.
- **Mochila táctica:** volumen verde oliva `#4b5320/#556b2f`, tapa superior redondeada con correas negras y hebillas, **dos bolsillos laterales con solapa**, anillo exterior, cantimplora, **tirantes que pasan por encima de la ruana sobre los hombros**.
- **Rostro:** cejas definidas, ojos con esclerótica/iris/pupula/reflejo, nariz con fosas, orejas, boca, barba y patillas; **manos articuladas** (palma + 4 dedos curvados + pulgar) que empuñan el arma con **ambas manos** (derecha en la empuñadura/gatillo, izquierda en el guardamanos).
- **Cel-shaded:** `MeshToonMaterial` con **mapa de gradiente** de 4 pasos (`DataTexture` con `NearestFilter`) + **contornos de tinta** por casco invertido (`side: BackSide`, escala 1,035) gestionados globalmente por `src/three/ToonManager.tsx`.

## Pilar 2 — Rig jerárquico y animación (`Character.tsx` + `store.action`)

**Jerarquía estricta de pivotes** (nombres verificados por test):

```
personaje → cadera → [pelvis, cinturón]
                 └─ columna → pecho → ruana, mochila, montura del arma, botiquín
                                    ├─ hombro izq/der → codo → mano
                                    └─ cuello → cabeza → sombrero
                          ├─ pierna izq/der → rodilla → tobillo → bota
                          └─ polvo (pool 8) · chispas (pool 10)
```

**Máquina de animación con interpolación amortiguada** (`THREE.MathUtils.damp`, λ=11 → *lerp* real entre estados, sin cortes bruscos). Ángulos de brazo resueltos por **cinemática inversa numérica** (45 000 iteraciones de búsqueda aleatoria con penalización de naturalidad del codo) para que las manos toquen el fusil en cada pose (test: distancia < 9 cm):

| Estado | Implementación |
|---|---|
| **Idle (reposo táctico)** | Respiración del torso (escala + micro-rotación), escaneo de cabeza, balanceo de rodillas, ruana y mochila con retardo; arma en guardia |
| **Caminar / Correr (sprint)** | Ciclo de locomoción procedural a 7,6 rad/s: flexión real de caderas (±0,8 rad), rodillas (hasta 1,3 rad), tobillos, balanceo pélvico, inclinación del torso hacia adelante (0,24), contrarrotación del pecho, balanceo de ruana/mochila, fusil a dos manos en posición low-ready |
| **Salto / Caída libre** | Bucle 1,1 s en tres fases: anticipación en cuclillas → aire con rodillas recogidas y arco parabólico → aterrizaje absorbido con flexión |
| **Parkour / Vault (0,45 s)** | Bucle 0,9 s con dos pasadas alternadas: pierna líder extendida sobre el obstáculo, pierna de impulso flexionada, **torso inclinado lateralmente** (`spineZ ±0,34`) y rotación pélvica, sin perder la sujeción del rifle |
| **Derrape táctico (Slide)** | Bucle 1,6 s: cadera a −0,34, torso hacia atrás, **pierna delantera extendida** y trasera plegada, **seguir apuntando** (IK en pose de tiro) + **polvo (pool de 8 esferas, sin asignaciones en bucle)** |
| **Curación (2 s)** | Ambas manos al frente (IK simétrico) sosteniendo botiquín con cruz roja, **chispas verdes ascendentes (pool de 10)**, mirada hacia el objeto, arma retraída (escala amortiguada a 0) |
| **Recoil + fogonazo** | Variante «Disparando»: retroceso del arma al hombro, fogonazo de 3 conos + luz puntual en `AK47.tsx` |

- **Cero `new THREE.*` dentro del bucle de animación:** todos los pools, temporizadores y objetos de apoyo se crean una vez (`useRef`/`useMemo`).
- Transiciones: el pose *objetivo* se recalcula cada frame y el pose *actual* se amortigua hacia él → cualquier cambio de estado es continuo.

## Pilar 3 — Dirección de arte, iluminación y sombras (`src/three/Viewer.tsx`)

- **`gl.shadowMap.type = THREE.PCFSoftShadowMap`** explícito en `onCreated`.
- Luz direccional cálida (`#fff3dc`, intensidad 2,6) con **`shadow.mapSize [2048, 2048]`**, `bias −0,00025`, `normalBias 0,035`, frustum cuadrado **ajustado dinámicamente al radio del modelo** (izq/dcha/arriba/abajo = radio×1,7, far = radio×14) y objetivo sigue al modelo. Cubierta por hemisférica + relleno azul frío + ambiental.
- `castShadow`/`receiveShadow` en personaje (silueta del sombrero, mochila y piernas), edificios, puente, palmas y rocas; suelo con `shadowMaterial` (sombra suave sobre cualquier fondo).
- **Niebla atmosférica `FogExp2`** con transición a **tormenta púrpura**: color y densidad interpolados por estado `storm` (p. ej. cielo `#b9c6e4` d=0,0105 → `#4b3f6e` d=0,032).
- Sombra de contacto + rejilla de suelo con desvanecimiento, gizmo de ejes, 4 fondos (estudio/cielo/oscuro/blanco).

## Pilar 4 — Valle del Cocora y monumento (`FullScene.tsx`, `Props.tsx`, `WaxPalm.tsx`)

- **Monumento `COCORA`**: letras 3D reales (`TextGeometry` con fuente incrustada, biselado) + estructura metálica (postes, travesaños, diagonales) + base arbustiva; **escultura de cóndor andino con alas desplegadas posado sobre la letra «R»** (variante «Sobre la colina» inclinada por la ladera). Cóndores vivos planeando en el cielo (bucle orbital con aleteo amortiguado).
- **Palmas de cera:** tronco anillado con textura procedural, copa de **19 frondas** generadas por `CatmullRomCurve3` + `TubeGeometry` con foliolos articulados, frondas muertas amarillas y racimos de frutos rojos; balanceo por viento (`rotation.z = sin(t)`), 26 ejemplares sembrados con RNG determinista.
- **Río + puente:** río caudaloso con textura animada (`map.offset`), espuma blanca sobre rocas del cauce, orillas de arena, y **puente arqueado de mampostería** nivelado sobre el agua (cuerpo extruido con arco, 19 dovelas, pretiles, estribos, piedras en relieve).
- Terreno procedural 72×72 m (110² segmentos) con colinas, lechos de río, camino empedrado, **cráter de explosión** con suelo calcinado y rocas; niebla que funde la ladera lejana.

## Pilar 5 — Estructuras, vehículos y puntos de interés

- **Pueblo paisa:** 3 casas (dos de 2 pisos + una de 1 piso) con zócalo de piedra **nivelado sobre el terreno (cero huecos)**, muros encalados, cornisa, hastiales, techo de teja con **tejas 3D generadas una sola vez y fusionadas**, balcón de madera con repisa, pretiles torneados (postes+cadenciales fusionados), macetas con geranios, puertas de panel con herrajes, ventanas con contraventanas de colores, farol.
- **Helicóptero estrellado:** fuselaje inclinado, cabina con parabrisas, puertas, motor y tobera, patines (uno deformado), **pala doblada**, **cola partida con turbohélice giratoria y cola desprendida**, escombros, suelo quemado, **fuego (13 conos agrupados + luces puntuales parpadeantes)** y **columna de humo (10 esferas en pool con ciclo de vida)**; variante intacta con rotor a 26 rad/s y disco de turbina.
- **Cercas** saltables con postes de travesaños, pilares de piedra apilada y pasto; **cafetales** con cerezas rojas/verdes; rocas con musgo por vértice; **danta de montaña** con ciclo de marcha/pastoreo.

## Pilar 6 — Dinámicas y balance

Al no existir bucle de juego ni servidor en este proyecto, las dinámicas se representan en el visor: **prompt contextual `[E] RECOGER BOTIQUÍN`** y barra de salud que sube de 85→100 durante la curación; el auto-pickup/daño por caída/oso se documentan como contenido de juego no aplicable aquí. El HUD y los estados del personaje sí están implementados (pilares 2 y 7).

## Pilar 7 — HUD exacto (`src/components/Hud.tsx`)

Réplica del HUD de la referencia, **sin re-renders** (bucle `requestAnimationFrame` que lee `live`/`store.getState()`):

- **Superior izquierda:** minimapa 148² con borde púrpura, terreno, colinas, **río turquesa**, sendero emparedado, pueblo, cráter en llamas, retícula, **viñeta de tormenta** y **flecha del jugador** que gira con el encuadre de cámara (`live.heading`); debajo `VIVOS: 14` y `BAJAS: 3`.
- **Superior derecha:** `VIVOS: 14`, `BAJAS: 3`, botón de audio (Volume2/VolumeX) y **contador de FPS en vivo** (target 60).
- **Centro:** mira de 4 trazos con punto; **centro inferior:** aviso contextual `[E] RECOGER BOTIQUÍN` (cambia a `CURANDO…`) y **barra verde `SALUD` `85/100`** con relleno amortiguado.
- **Inferior derecha:** `FUSIL ANDINO AK-47`, **silueta SVG del arma** y munición `25/75` (ciclo de disparo animado cuando la variante es «Disparando»).
- Encendido/apagado desde la barra superior (icono de mira) o desde *Visualización → HUD de juego*.

## Pilar 8 — Rendimiento (60 FPS) y registro

1. **Sin asignaciones en `animate()`:** pools fijos de partículas (humo 10, fuego 13, polvo 8, chispas 10, burbujas 4), geometrías precalculadas y cacheadas (`Map` de copas de palma, arbustos de café, rocas), temporizadores en `useRef`, vectores de trabajo a nivel de módulo (`_dir`).
2. **Reducción de draw calls:** geometrías **fusionadas** con `mergeGeometries` (tejas, dovelas, pretiles, flecos, frondas, arbustos, escombros, rocas, pasto) — equivalente en coste a `InstancedMesh` para geometría estática y con menos overhead de actualización de matrices. Las 26 palmas comparten geometrías de copa cacheadas por semilla.
3. **Límites automáticos para mantener 60 FPS:** tapas de corte desactivadas >420 mallas; contornos desactivados >260 mallas (aviso visible en UI); `dpr` limitado a [1, 1.75]; sombras 2048² con frustum ajustado.
4. **Pruebas automatizadas (39):** render + animación de las 29 variantes de modelos sin NaN, jerarquía del rig, **IK mano→fusil < 9 cm**, botiquín en curación, sistema de cortes con tapas stencil, explosión/despiece, exportación OBJ/STL/GLB/PNG y cel-shading (conversión, contorno y reversión).
5. **Socket.IO / `server/gameRoom.js`:** no aplicable — no hay servidor ni red en esta aplicación de visor single-file.
6. **Este archivo** (`CONTEXTO.md`) es el registro requerido.

---

## Mapa de archivos

| Archivo | Contenido |
|---|---|
| `src/store.ts` | Estado global (Zustand): modelo, variante, movimiento, cortes, cel-shading, tormenta, HUD, acciones + `live` (FPS/encuadre) |
| `src/three/models/Character.tsx` | **Personaje completo**: rig, poses IK, animación procedural, sombrero/ruana/mochila/rostro |
| `src/three/models/AK47.tsx` | Fusil con madera/metál, cargador extruido, fogonazo y retroceso |
| `src/three/models/Helicopter.tsx` | Huey estrellado/intacto con rotor, fuego y humo |
| `src/three/models/ColonialHouse.tsx` · `StoneBridge.tsx` · `WaxPalm.tsx` · `Fauna.tsx` · `Props.tsx` · `FullScene.tsx` | Arquitectura, naturaleza, fauna, objetos y diorama completo |
| `src/three/ToonManager.tsx` | Conversión a `MeshToonMaterial` + contornos de casco invertido |
| `src/three/ClippingManager.tsx` | Planos de corte, tapas stencil, despiece, estadísticas |
| `src/three/Viewer.tsx` | Canvas, luces PCFSoft 2048, niebla/tormenta, cámara, rejilla, gizmo |
| `src/three/exporters.ts` | GLB / GLTF / OBJ / STL / PNG |
| `src/components/Hud.tsx` · `ControlPanel.tsx` · `Sidebar.tsx` | HUD de referencia, panel de control y biblioteca de modelos |
| `src/__tests__/*.test.tsx` | 39 pruebas (modelos, rig/IK/cel-shading, cortes, exportación) |
