// @vitest-environment jsdom
import { describe, it, expect, beforeAll, afterEach } from 'vitest'
import * as THREE from 'three'
import ReactThreeTestRenderer from '@react-three/test-renderer'
import { createRef } from 'react'
import { Character } from '../three/models/Character'
import { ColonialHouse } from '../three/models/ColonialHouse'
import { ToonManager } from '../three/ToonManager'
import { useStore, type Action } from '../store'

beforeAll(() => {
  const noop = () => undefined
  const ctxProxy = new Proxy({}, { get: (_, key) => (key === 'canvas' ? {} : key === 'createRadialGradient' || key === 'createLinearGradient' ? () => ({ addColorStop: noop }) : noop), set: () => true })
  ;(HTMLCanvasElement.prototype as unknown as { getContext: () => unknown }).getContext = () => ctxProxy
})

afterEach(() => {
  useStore.setState({ action: 'idle', toon: true, outline: true, outlineLimited: false })
})

const tick = () => new Promise((r) => setTimeout(r, 0))

describe('personaje: rig y animación', () => {
  const ACTIONS: Action[] = ['idle', 'run', 'jump', 'vault', 'slide', 'heal']

  for (const action of ACTIONS) {
    it(`acción «${action}» anima sin valores NaN`, async () => {
      useStore.setState({ action })
      const ref = createRef<THREE.Group>()
      const renderer = await ReactThreeTestRenderer.create(
        <group ref={ref}>
          <Character variant={0} />
        </group>,
      )
      await renderer.advanceFrames(40, 0.033)
      const root = ref.current!
      let meshes = 0
      root.traverse((o) => {
        expect(Number.isNaN(o.position.x) || Number.isNaN(o.rotation.x)).toBe(false)
        const m = o as THREE.Mesh
        if (m.isMesh) {
          meshes++
          const pos = m.geometry.attributes.position as THREE.BufferAttribute
          for (let i = 0; i < pos.count; i++) expect(Number.isNaN(pos.getX(i))).toBe(false)
        }
      })
      expect(meshes).toBeGreaterThan(40)
      await renderer.unmount()
    })
  }

  it('jerarquía estricta del rig', async () => {
    const ref = createRef<THREE.Group>()
    const renderer = await ReactThreeTestRenderer.create(
      <group ref={ref}>
        <Character variant={0} />
      </group>,
    )
    const root = ref.current!
    const names: string[] = []
    root.traverse((o) => { if (o.name) names.push(o.name) })
    for (const n of ['cadera', 'columna', 'pecho', 'cuello', 'cabeza', 'sombrero vueltiao', 'ruana', 'mochila', 'montura del arma', 'hombro derecho', 'hombro izquierdo', 'codo derecho', 'codo izquierdo', 'mano derecha', 'mano izquierda', 'pierna derecha', 'pierna izquierda', 'rodilla derecha', 'rodilla izquierda', 'tobillo derecho', 'tobillo izquierdo', 'botiquín en mano']) {
      expect(names).toContain(n)
    }
    await renderer.unmount()
  })

  it('las manos empuñan el fusil (IK) en la pose de apuntado', async () => {
    useStore.setState({ action: 'idle' })
    const ref = createRef<THREE.Group>()
    const renderer = await ReactThreeTestRenderer.create(
      <group ref={ref}>
        <Character variant={0} />
      </group>,
    )
    await renderer.advanceFrames(60, 0.033)
    const root = ref.current!
    let handR: THREE.Object3D | undefined, handL: THREE.Object3D | undefined, mount: THREE.Object3D | undefined
    root.traverse((o) => {
      if (o.name === 'mano derecha') handR = o
      if (o.name === 'mano izquierda') handL = o
      if (o.name === 'montura del arma') mount = o
    })
    expect(handR && handL && mount).toBeTruthy()
    root.updateWorldMatrix(true, true)
    const grip = new THREE.Vector3(-0.075 * 0.88, -0.06 * 0.88, 0).applyMatrix4(mount!.matrixWorld)
    const guard = new THREE.Vector3(0.225 * 0.88, -0.01 * 0.88, 0).applyMatrix4(mount!.matrixWorld)
    const dR = handR!.getWorldPosition(new THREE.Vector3()).distanceTo(grip)
    const dL = handL!.getWorldPosition(new THREE.Vector3()).distanceTo(guard)
    expect(dR).toBeLessThan(0.09)
    expect(dL).toBeLessThan(0.12)
    await renderer.unmount()
  })

  it('el botiquín aparece durante la curación', async () => {
    useStore.setState({ action: 'heal' })
    const ref = createRef<THREE.Group>()
    const renderer = await ReactThreeTestRenderer.create(
      <group ref={ref}>
        <Character variant={0} />
      </group>,
    )
    await renderer.advanceFrames(40, 0.033)
    let medkit: THREE.Object3D | undefined
    ref.current!.traverse((o) => { if (o.name === 'botiquín en mano') medkit = o })
    expect(medkit).toBeTruthy()
    expect(medkit!.scale.x).toBeGreaterThan(0.9)
    await renderer.unmount()
  })
})

describe('cel-shading global', () => {
  it('convierte materiales a toon y añade/retira contornos', async () => {
    useStore.setState({ toon: true, outline: true })
    const ref = createRef<THREE.Group>()
    const renderer = await ReactThreeTestRenderer.create(
      <group ref={ref}>
        <ColonialHouse variant={0} />
        <ToonManager target={ref} />
      </group>,
    )
    await tick()
    await renderer.advanceFrames(2, 0.05)
    await tick()
    let toon = 0, outlines = 0
    ref.current!.traverse((o) => {
      const m = o as THREE.Mesh
      if (!m.isMesh) return
      if ((m.material as THREE.Material).type === 'MeshToonMaterial') toon++
      if (m.userData?.isOutline) outlines++
    })
    expect(toon).toBeGreaterThan(20)
    expect(outlines).toBeGreaterThan(20)

    useStore.setState({ outline: false })
    await tick()
    await renderer.advanceFrames(2, 0.05)
    await tick()
    let after = 0
    ref.current!.traverse((o) => { if ((o as THREE.Mesh).userData?.isOutline) after++ })
    expect(after).toBe(0)

    useStore.setState({ toon: false })
    await tick()
    await renderer.advanceFrames(2, 0.05)
    await tick()
    let standards = 0
    ref.current!.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.isMesh && (m.material as THREE.Material).type === 'MeshStandardMaterial') standards++
    })
    expect(standards).toBeGreaterThan(20)
    await renderer.unmount()
  })
})
