import { useEffect, useRef, useState } from 'react'
import { Volume2, VolumeX } from 'lucide-react'
import { useStore, live } from '../store'
import { cn } from '../utils/cn'

const HP_BASE = 85

function Chip({ label, value, className }: { label: string; value: string | number; className?: string }) {
  return (
    <span className={cn('rounded bg-zinc-950/85 px-2 py-1 text-[11px] font-semibold tracking-wide text-white shadow backdrop-blur-sm', className)}>
      {label} <span className="font-mono">{value}</span>
    </span>
  )
}

function riverX(z: number) { return 13 + 3 * Math.sin(z * 0.11) + 1.2 * Math.sin(z * 0.31) }
function pathX(z: number) { return -2 + 2.5 * Math.sin(z * 0.09 + 1) }

function drawBaseMap(ctx: CanvasRenderingContext2D, S: number) {
  const w = (v: number) => ((v + 36) / 72) * S
  // Terreno
  const g = ctx.createLinearGradient(0, 0, S, S)
  g.addColorStop(0, '#7ec255'); g.addColorStop(0.5, '#57a63a'); g.addColorStop(1, '#3f8a30')
  ctx.fillStyle = g; ctx.fillRect(0, 0, S, S)
  // Colinas
  ctx.fillStyle = 'rgba(30,80,30,0.28)'
  for (const [x, z, r] of [[-26, -26, 13], [20, -28, 14], [-30, 2, 11], [30, 10, 9]] as [number, number, number][]) {
    ctx.beginPath(); ctx.arc(w(x), w(z), (r / 72) * S, 0, Math.PI * 2); ctx.fill()
  }
  // Río
  ctx.lineCap = 'round'; ctx.lineJoin = 'round'
  ctx.strokeStyle = '#3f9fd8'; ctx.lineWidth = S * 0.075
  ctx.beginPath()
  for (let z = -36; z <= 36; z += 2) { const x = w(riverX(z)); const y = w(z); z === -36 ? ctx.moveTo(x, y) : ctx.lineTo(x, y) }
  ctx.stroke()
  ctx.strokeStyle = '#8fd4f5'; ctx.lineWidth = S * 0.03
  ctx.stroke()
  // Sendero
  ctx.strokeStyle = '#c9a978'; ctx.lineWidth = S * 0.035; ctx.setLineDash([4, 4])
  ctx.beginPath()
  for (let z = -16; z <= 34; z += 2) { const x = w(pathX(z)); const y = w(z); z === -16 ? ctx.moveTo(x, y) : ctx.lineTo(x, y) }
  ctx.stroke(); ctx.setLineDash([])
  // Pueblo
  ctx.fillStyle = '#e9e3d4'
  for (const [x, z] of [[-16, -4], [-11.5, -11], [-19, 4.5]]) ctx.fillRect(w(x) - 4, w(z) - 4, 8, 8)
  // Helicóptero / cráter
  ctx.fillStyle = '#2b2622'; ctx.beginPath(); ctx.arc(w(-3), w(-2), S * 0.035, 0, Math.PI * 2); ctx.fill()
  ctx.fillStyle = '#f08a1e'; ctx.beginPath(); ctx.arc(w(-3), w(-2), S * 0.015, 0, Math.PI * 2); ctx.fill()
}

export function Hud() {
  const hud = useStore((s) => s.hud)
  const action = useStore((s) => s.action)
  const variant = useStore((s) => s.variant)
  const modelId = useStore((s) => s.modelId)
  const mapRef = useRef<HTMLCanvasElement>(null)
  const hpFill = useRef<HTMLDivElement>(null)
  const hpText = useRef<HTMLSpanElement>(null)
  const fpsRef = useRef<HTMLSpanElement>(null)
  const ammoRef = useRef<HTMLSpanElement>(null)
  const [audio, setAudio] = useState(true)

  useEffect(() => {
    if (!hud) return
    const S = 148
    const base = document.createElement('canvas')
    base.width = S; base.height = S
    const bctx = base.getContext('2d')
    if (bctx) drawBaseMap(bctx, S)
    const ctx = mapRef.current?.getContext('2d') ?? null
    let raf = 0, last = 0, frames = 0, lastFps = performance.now()
    let hp = HP_BASE, ammo = 25
    const loop = (now: number) => {
      raf = requestAnimationFrame(loop)
      frames++
      if (now - lastFps > 500) {
        live.fps = Math.round((frames * 1000) / (now - lastFps))
        if (fpsRef.current) fpsRef.current.textContent = `${live.fps} FPS`
        frames = 0; lastFps = now
      }
      const st = useStore.getState()
      // ---- Minimapa (15 fps) ----
      if (ctx && now - last > 66) {
        last = now
        ctx.clearRect(0, 0, S, S)
        if (base) ctx.drawImage(base, 0, 0)
        // tormenta en los bordes
        const storm = ctx.createRadialGradient(S / 2, S / 2, S * 0.3, S / 2, S / 2, S * 0.72)
        storm.addColorStop(0, 'rgba(168,85,247,0)')
        storm.addColorStop(1, st.storm ? 'rgba(147,51,234,0.92)' : 'rgba(168,85,247,0.45)')
        ctx.fillStyle = storm; ctx.fillRect(0, 0, S, S)
        // retícula
        ctx.strokeStyle = 'rgba(255,255,255,0.14)'; ctx.lineWidth = 1
        ctx.beginPath(); ctx.moveTo(S / 2, 0); ctx.lineTo(S / 2, S); ctx.moveTo(0, S / 2); ctx.lineTo(S, S / 2); ctx.stroke()
        // flecha del jugador
        ctx.save()
        ctx.translate(S / 2, S / 2)
        ctx.rotate(live.heading)
        ctx.fillStyle = '#ffffff'
        ctx.strokeStyle = 'rgba(0,0,0,0.55)'; ctx.lineWidth = 1.5
        ctx.beginPath(); ctx.moveTo(0, -8); ctx.lineTo(6, 7); ctx.lineTo(0, 3.5); ctx.lineTo(-6, 7); ctx.closePath()
        ctx.fill(); ctx.stroke()
        ctx.restore()
        // círculo de recorte
        ctx.strokeStyle = 'rgba(255,255,255,0.35)'; ctx.lineWidth = 2
        ctx.beginPath(); ctx.arc(S / 2, S / 2, S / 2 - 2, 0, Math.PI * 2); ctx.stroke()
      }
      // ---- Salud ----
      const targetHp = st.action === 'heal' ? 100 : HP_BASE
      hp += (targetHp - hp) * 0.05
      const shown = Math.round(hp)
      if (hpFill.current) hpFill.current.style.width = `${hp}%`
      if (hpText.current) hpText.current.textContent = `${shown}/100`
      // ---- Munición ----
      let targetAmmo = 25
      if (st.variant === 1 && st.modelId === 'personaje') {
        const cycle = (now / 1000) % 3.2
        targetAmmo = cycle < 2.4 ? Math.max(0, 25 - Math.floor(cycle * 11)) : 25
      }
      if (targetAmmo !== ammo) {
        ammo += Math.sign(targetAmmo - ammo)
        if (ammoRef.current) ammoRef.current.textContent = `${ammo}`
      }
    }
    raf = requestAnimationFrame(loop)
    return () => cancelAnimationFrame(raf)
  }, [hud])

  if (!hud) return null
  const firing = variant === 1 && modelId === 'personaje'

  return (
    <div className="pointer-events-none absolute inset-0 z-20 select-none">
      {/* ---------- Minimapa ---------- */}
      <div className="absolute left-3 top-3">
        <div className="rounded-lg border-[3px] border-purple-500/85 bg-zinc-950/85 p-[3px] shadow-[0_4px_18px_rgba(0,0,0,0.45)]">
          <canvas ref={mapRef} width={148} height={148} className="block rounded-[4px]" />
        </div>
        <div className="mt-1.5 flex gap-1.5">
          <Chip label="VIVOS:" value={14} />
          <Chip label="BAJAS:" value={3} />
        </div>
      </div>

      {/* ---------- Contadores + audio + FPS ---------- */}
      <div className="absolute right-3 top-3 flex items-center gap-1.5">
        <Chip label="VIVOS:" value={14} />
        <Chip label="BAJAS:" value={3} />
        <button
          onClick={() => setAudio(!audio)}
          className="pointer-events-auto rounded bg-zinc-950/85 p-1.5 text-white shadow backdrop-blur-sm transition hover:bg-zinc-800"
          title={audio ? 'Silenciar' : 'Activar audio'}
        >
          {audio ? <Volume2 className="h-3.5 w-3.5" /> : <VolumeX className="h-3.5 w-3.5 text-zinc-400" />}
        </button>
        <span ref={fpsRef} className="rounded bg-zinc-950/85 px-2 py-1 font-mono text-[11px] font-semibold text-emerald-400 shadow backdrop-blur-sm">60 FPS</span>
      </div>

      {/* ---------- Mira ---------- */}
      <svg className="absolute left-1/2 top-1/2 h-7 w-7 -translate-x-1/2 -translate-y-1/2" viewBox="0 0 28 28" fill="none">
        <path d="M14 1v7M14 20v7M1 14h7M20 14h7" stroke="rgba(255,255,255,0.9)" strokeWidth="1.6" />
        <path d="M14 1v7M14 20v7M1 14h7M20 14h7" stroke="rgba(0,0,0,0.45)" strokeWidth="3" opacity="0.35" />
        <circle cx="14" cy="14" r="1.3" fill="#fff" />
      </svg>

      {/* ---------- Prompt contextual + salud ---------- */}
      <div className="absolute bottom-4 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2">
        <div className="rounded bg-zinc-950/85 px-3 py-1.5 text-[13px] font-semibold tracking-wide text-white shadow backdrop-blur-sm">
          <span className="mr-1 rounded bg-amber-400/90 px-1 font-mono text-zinc-950">[E]</span>
          {action === 'heal' ? 'CURANDO…' : 'RECOGER BOTIQUÍN'}
        </div>
        <div className="flex items-center gap-2 rounded bg-zinc-950/85 px-2.5 py-1.5 shadow backdrop-blur-sm">
          <span className="text-[12px] font-bold tracking-wider text-white">SALUD</span>
          <div className="h-3.5 w-40 overflow-hidden rounded-sm bg-zinc-800 ring-1 ring-black/50">
            <div ref={hpFill} className="h-full bg-gradient-to-r from-emerald-500 to-green-400 transition-[width] duration-100" style={{ width: `${HP_BASE}%` }} />
          </div>
          <span ref={hpText} className="w-14 text-right font-mono text-[12px] font-semibold text-white">{HP_BASE}/100</span>
        </div>
      </div>

      {/* ---------- Panel de arma ---------- */}
      <div className="absolute bottom-4 right-4 rounded-lg bg-zinc-950/85 px-3 py-2 shadow-[0_4px_18px_rgba(0,0,0,0.45)] backdrop-blur-sm">
        <div className="mb-1 text-right text-[12px] font-semibold tracking-wide text-white">FUSIL ANDINO AK-47</div>
        <div className="flex items-end gap-4">
          <svg viewBox="0 0 124 42" className="h-10 w-32 text-white" fill="currentColor" aria-hidden>
            <path d="M6 16 L30 13 L30 22 L16 24 L10 30 L20 31 L30 24 L30 27 L36 27 L36 21 L44 21 L44 34 L37 37 L31 34 L44 21 L52 21 L54 33 L62 37 L70 34 L68 21 L74 21 L74 17 L104 17 L110 15 L118 15 L118 20 L110 20 L104 22 L74 22 L74 25 L64 25 L60 31 L52 31 L48 25 L44 25 L44 21 L36 21 L36 16 L30 16 L30 13 L6 16 Z" />
            <rect x="74" y="12" width="22" height="3.4" />
            <rect x="99" y="9" width="3.4" height="7" />
            <rect x="112" y="13" width="7" height="5" />
            <path d="M46 21 L58 21 L62 33 L54 38 L46 35 Z" opacity="0.95" />
          </svg>
          <div className="text-right leading-none">
            <span ref={ammoRef} className="font-mono text-3xl font-bold text-white">25</span>
            <span className="font-mono text-lg font-medium text-zinc-400">/75</span>
            <div className={cn('mt-1 text-[10px] font-semibold tracking-wider', firing ? 'text-red-400' : 'text-emerald-400')}>
              {firing ? 'DISPARANDO' : 'LISTO'}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}


