import * as THREE from 'three'
import { useEffect, useRef } from 'react'
import { useStore } from '../store'

const OUTLINE_COLOR = '#17120e'
const OUTLINE_SCALE = 1.035
const MAX_OUTLINE_MESHES = 260

type Marked = { __orig?: THREE.Material; __toon?: boolean }

function toToon(src: THREE.MeshStandardMaterial): THREE.MeshToonMaterial {
  const m = new THREE.MeshToonMaterial({
    color: src.color.clone(),
    map: src.map,
    emissive: src.emissive.clone(),
    emissiveIntensity: src.emissiveIntensity,
    transparent: src.transparent,
    opacity: src.opacity,
    alphaMap: src.alphaMap,
    side: src.side,
    depthWrite: src.depthWrite,
    vertexColors: src.vertexColors,
    fog: src.fog,
  })
  m.name = src.name
  m.clippingPlanes = src.clippingPlanes
  m.clipShadows = src.clipShadows
  ;(m as Marked).__orig = src
  return m
}

/** Convierte los materiales del modelo a toon (cel-shaded) y añade contornos de casco invertido. */
export function ToonManager({ target }: { target: React.RefObject<THREE.Group | null> }) {
  const toon = useStore((s) => s.toon)
  const outline = useStore((s) => s.outline)
  const modelId = useStore((s) => s.modelId)
  const variant = useStore((s) => s.variant)
  const sig = useRef('')

  useEffect(() => {
    const root = target.current
    if (!root) return
    const key = `${modelId}|${variant}|${toon}|${outline}`
    if (sig.current === key) return
    sig.current = key

    const meshes: THREE.Mesh[] = []
    root.traverse((o) => {
      const m = o as THREE.Mesh
      if (m.isMesh && !m.userData?.isOutline) meshes.push(m)
    })

    // 1 · Materiales → toon
    for (const mesh of meshes) {
      const multi = Array.isArray(mesh.material)
      const mats = multi ? (mesh.material as THREE.Material[]) : [mesh.material as THREE.Material]
      let changed = false
      const next = mats.map((mat) => {
        const marked = mat as unknown as Marked
        const std = mat as THREE.MeshStandardMaterial
        if (toon && std.isMeshStandardMaterial && !marked.__toon) {
          const conv = toToon(std)
          ;(conv as unknown as Marked).__toon = true
          changed = true
          return conv as THREE.Material
        }
        if (!toon && marked.__orig) {
          changed = true
          return marked.__orig
        }
        return mat
      })
      if (changed) mesh.material = multi ? (next as THREE.Material[]) : next[0]
    }

    // 2 · Contornos (casco invertido)
    const countable = meshes.filter((m) => !m.userData?.noCap && !(m.material as THREE.Material)?.transparent)
    const limited = outline && countable.length > MAX_OUTLINE_MESHES
    const want = outline && !limited
    if (limited !== useStore.getState().outlineLimited) useStore.setState({ outlineLimited: limited })

    for (const mesh of countable) {
      const existing = mesh.children.find((c) => (c as THREE.Mesh).userData?.isOutline) as THREE.Mesh | undefined
      if (want && !existing) {
        const om = new THREE.Mesh(mesh.geometry, new THREE.MeshBasicMaterial({ color: OUTLINE_COLOR, side: THREE.BackSide, fog: true }))
        om.name = 'contorno'
        om.userData.isOutline = true
        om.userData.noCap = true
        om.userData.noExport = true
        om.castShadow = false
        om.receiveShadow = false
        om.scale.setScalar(OUTLINE_SCALE)
        mesh.add(om)
      } else if (!want && existing) {
        mesh.remove(existing)
        ;(existing.material as THREE.Material).dispose()
      }
    }
  }, [toon, outline, modelId, variant, target])

  return null
}
