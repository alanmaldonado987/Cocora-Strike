import * as THREE from 'three'
import { useEffect, useMemo, useRef, type ReactNode } from 'react'
import type { ThreeElements } from '@react-three/fiber'
import { useStore, type Action } from '../../store'
import { GeoBuilder, TEX, useAnim, type V3 } from '../helpers'
import { AK47 } from './AK47'

/* ================================================================== */
/*  Cel-shading: mapa de gradiente para MeshToonMaterial               */
/* ================================================================== */
const GRADIENT = (() => {
  const data = new Uint8Array([58, 128, 196, 255])
  const tex = new THREE.DataTexture(data, data.length, 1, THREE.RedFormat)
  tex.minFilter = THREE.NearestFilter
  tex.magFilter = THREE.NearestFilter
  tex.generateMipmaps = false
  tex.needsUpdate = true
  return tex
})()

interface TP {
  p?: V3; r?: V3; s?: V3 | number; c?: string; map?: THREE.Texture
  emissive?: string; emissiveIntensity?: number; transparent?: boolean; opacity?: number
  name?: string; geo?: ReactNode; geometry?: THREE.BufferGeometry; noCap?: boolean; basic?: boolean
  cast?: boolean; recv?: boolean; visible?: boolean; children?: ReactNode
}

/** Primitiva con acabado toon (cel-shaded). */
function T({ p, r, s, c = '#ffffff', map, emissive, emissiveIntensity, transparent, opacity, name, geo, geometry, noCap, basic, cast = true, recv = true, visible, children }: TP) {
  const ud = useMemo(() => (noCap ? { noCap: true } : {}), [noCap])
  const extra: Record<string, unknown> = {}
  if (p) extra.position = p
  if (r) extra.rotation = r
  if (s !== undefined) extra.scale = s
  if (name) extra.name = name
  if (visible !== undefined) extra.visible = visible
  const meshExtra = extra as Partial<ThreeElements['mesh']>
  const mat = basic ? (
    <meshBasicMaterial color={c} map={map} transparent={transparent} opacity={opacity} />
  ) : (
    <meshToonMaterial color={c} map={map} gradientMap={GRADIENT} emissive={emissive} emissiveIntensity={emissiveIntensity} transparent={transparent} opacity={opacity} />
  )
  return (
    <mesh {...meshExtra} castShadow={cast} receiveShadow={recv} userData={ud}>
      {geometry ? <primitive object={geometry} attach="geometry" /> : geo}
      {mat}
      {children}
    </mesh>
  )
}

/* ================================================================== */
/*  Sistema de poses: pose objetivo por acción + amortiguación (lerp)  */
/* ================================================================== */
type Pose = Record<string, number>

/** Angulos resueltos por IK (hombro/codo) para que ambas manos empuñen el fusil. */
const AIM: Pose = {
  hipsY: 0, hipsX: 0.02, hipsYR: 0, hipsZ: 0,
  spineX: 0.05, spineY: -0.12, spineZ: 0, headX: 0.02, headY: -0.08,
  armLX: -1.08, armLY: 0, armLZ: 0.74, elbowL: -0.3,
  armRX: 0.31, armRY: -0.49, armRZ: 0.33, elbowR: -2.19,
  riflePX: 0.17, riflePY: 0.25, riflePZ: 0.25, rifleRX: -0.04, rifleRY: -Math.PI / 2, rifleRZ: 0,
  hipL: -0.04, kneeL: 0.1, ankleL: 0, hipR: 0.06, kneeR: 0.14, ankleR: 0,
  ruanaX: 0, ruanaZ: 0, packX: 0, medkit: 0, rifleVis: 1,
}
const RUN: Pose = {
  ...AIM,
  spineX: 0.24, spineY: 0, headX: -0.16, headY: 0,
  armLX: -0.75, armLZ: 0.69, elbowL: -0.3,
  armRX: 0.13, armRY: 0, armRZ: -0.36, elbowR: -1.0,
  riflePX: 0.1, riflePY: 0, riflePZ: 0.22, rifleRX: -0.6, rifleRY: -Math.PI / 2 + 0.2, rifleRZ: 0,
  hipL: 0, kneeL: 0.2, hipR: 0, kneeR: 0.2,
}
const JUMP: Pose = {
  ...AIM,
  spineX: 0.12, headX: -0.1,
  armLX: -1.14, armLZ: 0.68,
  armRX: 0.35, armRY: -0.01, armRZ: -0.73, elbowR: -1.94,
  riflePX: 0.12, riflePY: 0.22, riflePZ: 0.26, rifleRX: -0.3, rifleRY: -Math.PI / 2, rifleRZ: 0,
  hipL: -0.9, kneeL: 1.3, hipR: -0.4, kneeR: 0.9,
}
const VAULT: Pose = {
  ...AIM,
  spineX: 0.3, spineY: 0.15, spineZ: 0.1, headX: -0.2,
  armLX: -0.8, armLZ: 0.75,
  armRX: 0.43, armRY: 0, armRZ: -0.56, elbowR: -1.5,
  riflePX: 0.1, riflePY: 0.08, riflePZ: 0.2, rifleRX: -0.35, rifleRY: -Math.PI / 2 + 0.3, rifleRZ: 0,
  hipL: 0.2, kneeL: 0.6, hipR: -1.0, kneeR: 0.4,
}
const SLIDE: Pose = {
  ...AIM,
  spineX: -0.3, spineY: 0.12, headX: 0.12,
  armLX: -1.22, armLZ: 0.69,
  armRX: 0.19, armRY: 0.06, armRZ: -0.87, elbowR: -2.14,
  riflePX: 0.16, riflePY: 0.3, riflePZ: 0.3, rifleRX: -0.05, rifleRY: -Math.PI / 2, rifleRZ: 0,
  hipL: 0.5, kneeL: 1.6, hipR: -1.1, kneeR: 0.2,
  ruanaX: 0.25, packX: -0.2,
}
const HEAL: Pose = {
  ...AIM,
  spineX: 0.12, spineY: 0, headX: 0.26, headY: 0,
  armLX: -0.58, armLY: 0, armLZ: 0.38, elbowL: -1.22,
  armRX: -0.58, armRY: 0, armRZ: -0.38, elbowR: -1.22,
  riflePX: 0.24, riflePY: -0.1, riflePZ: 0.14, rifleRX: 1.0, rifleRY: -Math.PI / 2, rifleRZ: 0,
  hipL: -0.03, kneeL: 0.12, hipR: 0.05, kneeR: 0.16,
  medkit: 1, rifleVis: 0,
}
const BASE: Record<Action, Pose> = { idle: AIM, run: RUN, jump: JUMP, vault: VAULT, slide: SLIDE, heal: HEAL }

function buildTarget(action: Action, variant: number, t: number, out: Pose) {
  Object.assign(out, BASE[action])
  if (action === 'idle') {
    if (variant <= 1) Object.assign(out, AIM)
    const b = Math.sin(t * 1.5)
    out.spineX += b * 0.014
    out.hipsY = b * 0.007
    out.headY += Math.sin(t * 0.55) * 0.1
    out.headX += Math.sin(t * 0.9) * 0.02
    out.kneeL = 0.1 + b * 0.02
    out.kneeR = 0.14 - b * 0.02
    out.ruanaZ = Math.sin(t * 1.1) * 0.018
    out.packX = Math.sin(t * 1.5 + 0.6) * 0.012
    return
  }
  if (action === 'run') {
    const p = t * 7.6
    const s = Math.sin(p)
    out.hipL = -s * 0.8
    out.kneeL = 0.15 + Math.max(0, Math.sin(p + 1.6)) * 1.15
    out.ankleL = Math.sin(p + 0.4) * 0.35
    out.hipR = s * 0.8
    out.kneeR = 0.15 + Math.max(0, Math.sin(p + Math.PI + 1.6)) * 1.15
    out.ankleR = Math.sin(p + Math.PI + 0.4) * 0.35
    out.hipsY = -0.02 + Math.abs(s) * 0.055
    out.hipsX = 0.06
    out.hipsYR = -s * 0.07
    out.hipsZ = s * 0.03
    out.spineY = s * 0.09
    out.spineZ = -s * 0.04
    out.headX = -0.16
    out.ruanaZ = -s * 0.07
    out.ruanaX = -0.07
    out.packX = s * 0.04
    return
  }
  if (action === 'jump') {
    const u = (t % 1.1) / 1.1
    if (u < 0.22) {
      const k = u / 0.22
      out.hipsY = -0.16 * k
      out.hipL = out.hipR = -0.5 * k
      out.kneeL = out.kneeR = 1.0 * k
      out.ankleL = out.ankleR = -0.2 * k
      out.spineX = 0.3 * k
      out.headX = -0.1 * k
    } else if (u < 0.75) {
      const k = (u - 0.22) / 0.53
      const arc = Math.sin(k * Math.PI)
      out.hipsY = 0.04 + 0.09 * arc
      out.hipL = -1.25 - 0.25 * arc
      out.kneeL = 1.65
      out.ankleL = 0.4
      out.hipR = -0.5
      out.kneeR = 1.0
      out.ankleR = 0.25
      out.spineX = 0.12
      out.headX = -0.16
      out.ruanaX = -0.16 - 0.1 * arc
      out.packX = -0.1 * arc
    } else {
      const k = (u - 0.75) / 0.25
      const land = Math.sin(k * Math.PI)
      out.hipsY = -0.14 * land
      out.hipL = out.hipR = -0.45 * land
      out.kneeL = out.kneeR = 1.1 * land
      out.ankleL = out.ankleR = -0.15 * land
      out.spineX = 0.32 * land
      out.headX = -0.08 * land
      out.ruanaX = 0.12 * land
    }
    return
  }
  if (action === 'vault') {
    const u = (t % 0.9) / 0.9
    const side = u < 0.5 ? 1 : -1
    const v = u < 0.5 ? u / 0.5 : (u - 0.5) / 0.5
    const k = Math.sin(v * Math.PI)
    out.hipsY = -0.04 + 0.15 * k
    out.hipsZ = -side * 0.16 * k
    out.spineX = 0.4 * k
    out.spineY = side * 0.22 * k
    out.spineZ = -side * 0.34 * k
    out.headX = -0.22 * k
    if (side > 0) {
      out.hipR = -1.55 * k; out.kneeR = 0.45 * k; out.ankleR = -0.5 * k
      out.hipL = 0.55 * k; out.kneeL = 1.35 * k; out.ankleL = 0.3 * k
    } else {
      out.hipL = -1.55 * k; out.kneeL = 0.45 * k; out.ankleL = -0.5 * k
      out.hipR = 0.55 * k; out.kneeR = 1.35 * k; out.ankleR = 0.3 * k
    }
    out.ruanaX = -0.18 * k
    out.packX = -0.12 * k
    out.ruanaZ = -side * 0.12 * k
    return
  }
  if (action === 'slide') {
    const u = (t % 1.6) / 1.6
    const k = u < 0.18 ? u / 0.18 : u < 0.72 ? 1 : Math.max(0, 1 - (u - 0.72) / 0.28)
    out.hipsY = -0.34 * k
    out.hipsX = -0.15 * k
    out.hipR = -1.15 * k
    out.kneeR = 0.2 * k
    out.ankleR = 0.55 * k
    out.hipL = 0.55 * k
    out.kneeL = 1.7 * k
    out.ankleL = -0.25 * k
    out.spineX = -0.3 * k
    out.spineY = 0.15 * k
    out.spineZ = 0.1 * k
    out.headX = 0.14 * k
    out.ruanaX = 0.28 * k
    out.packX = -0.22 * k
    out.ruanaZ = 0.08 * k
    return
  }
  if (action === 'heal') {
    const b = Math.sin(t * 1.8)
    out.spineX += b * 0.012
    out.hipsY = b * 0.006
    out.headX = 0.26 + b * 0.02
    out.ruanaZ = Math.sin(t * 1.2) * 0.02
  }
}

/* ================================================================== */
/*  Personaje: rig jerárquico completo                                 */
/* ================================================================== */
const SKIN = '#c0865e'
const CREAM = '#f3efe4'
const TROUSER = '#3c414b'
const BOOT = '#4a2f1a'
const STRAP = '#23261f'

export function Character({ variant = 0 }: { variant?: number }) {
  const firing = variant === 1

  const R = {
    hips: useRef<THREE.Group>(null),
    spine: useRef<THREE.Group>(null),
    chest: useRef<THREE.Group>(null),
    ruana: useRef<THREE.Group>(null),
    pack: useRef<THREE.Group>(null),
    neck: useRef<THREE.Group>(null),
    head: useRef<THREE.Group>(null),
    shL: useRef<THREE.Group>(null), elL: useRef<THREE.Group>(null), haL: useRef<THREE.Group>(null),
    shR: useRef<THREE.Group>(null), elR: useRef<THREE.Group>(null), haR: useRef<THREE.Group>(null),
    hipL: useRef<THREE.Group>(null), kneeL: useRef<THREE.Group>(null), ankL: useRef<THREE.Group>(null),
    hipR: useRef<THREE.Group>(null), kneeR: useRef<THREE.Group>(null), ankR: useRef<THREE.Group>(null),
    weapon: useRef<THREE.Group>(null),
    medkit: useRef<THREE.Group>(null),
    dust: useRef<(THREE.Mesh | null)[]>([]),
    spark: useRef<(THREE.Mesh | null)[]>([]),
  }

  const cur = useRef<Pose>({})
  const target = useRef<Pose>({})
  const clock = useRef(0)

  const ruanaTex = useMemo(() => TEX.ruana(), [])
  const hatBrim = useMemo(() => TEX.sombreroBrim(), [])
  const hatBand = useMemo(() => TEX.sombreroBand(), [])

  /* Geometrías compartidas / construidas una sola vez */
  const fringe = useMemo(() => {
    const b = new GeoBuilder()
    const thread = new THREE.BoxGeometry(0.02, 0.1, 0.014)
    const n = 74
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2
      const sx = Math.sin(a), cz = Math.cos(a)
      if (Math.abs(sx) > 0.94) continue // huecos laterales para los brazos
      b.add(thread, [sx * 0.44, -0.4, cz * 0.296], [0, a, (i % 2 ? 1 : -1) * 0.06])
    }
    thread.dispose()
    return b.build()
  }, [])

  const hatBrimGeo = useMemo(() => {
    const pts: THREE.Vector2[] = []
    const prof: [number, number][] = [
      [0.155, 0.0], [0.24, 0.004], [0.33, 0.018], [0.4, 0.042], [0.44, 0.072], [0.452, 0.095],
      [0.446, 0.098], [0.434, 0.078], [0.39, 0.05], [0.32, 0.026], [0.235, 0.012], [0.155, 0.008],
    ]
    prof.forEach(([x, y]) => pts.push(new THREE.Vector2(x, y)))
    const g = new THREE.LatheGeometry(pts, 44)
    g.computeVertexNormals()
    return g
  }, [])

  const hatCrownGeo = useMemo(() => {
    const pts: THREE.Vector2[] = []
    const prof: [number, number][] = [
      [0.158, 0.0], [0.172, 0.03], [0.176, 0.075], [0.168, 0.115], [0.148, 0.145], [0.11, 0.165], [0.06, 0.176], [0.0, 0.179],
    ]
    prof.forEach(([x, y]) => pts.push(new THREE.Vector2(x, y)))
    const g = new THREE.LatheGeometry(pts, 40)
    g.computeVertexNormals()
    return g
  }, [])

  useEffect(() => () => { fringe.dispose(); hatBrimGeo.dispose(); hatCrownGeo.dispose() }, [fringe, hatBrimGeo, hatCrownGeo])

  /* ---------------- ciclo de animación ---------------- */
  useAnim((t, dt) => {
    clock.current = t
    const act = useStore.getState().action
    buildTarget(act, variant, t, target.current)
    const curP = cur.current
    const tgt = target.current
    const lam = 11
    for (const k in tgt) {
      const l = k === 'medkit' || k === 'rifleVis' ? 16 : lam
      const prev = curP[k]
      curP[k] = prev === undefined ? tgt[k] : THREE.MathUtils.damp(prev, tgt[k], l, dt)
    }
    const set = (g: THREE.Group | null, x: number, y: number, z: number) => { if (g) g.rotation.set(x, y, z) }
    if (R.hips.current) {
      R.hips.current.position.y = 0.98 + curP.hipsY
      R.hips.current.rotation.set(curP.hipsX, curP.hipsYR, curP.hipsZ)
    }
    set(R.spine.current, curP.spineX, curP.spineY, curP.spineZ)
    if (R.chest.current) R.chest.current.scale.y = 1 + Math.sin(t * 1.5) * 0.014
    set(R.head.current, curP.headX, curP.headY, 0)
    set(R.shL.current, curP.armLX, curP.armLY, curP.armLZ)
    set(R.shR.current, curP.armRX, curP.armRY, curP.armRZ)
    set(R.elL.current, curP.elbowL, 0, 0)
    set(R.elR.current, curP.elbowR, 0, 0)
    set(R.hipL.current, curP.hipL, 0, 0)
    set(R.hipR.current, curP.hipR, 0, 0)
    set(R.kneeL.current, curP.kneeL, 0, 0)
    set(R.kneeR.current, curP.kneeR, 0, 0)
    set(R.ankL.current, curP.ankleL, 0, 0)
    set(R.ankR.current, curP.ankleR, 0, 0)
    if (R.weapon.current) {
      R.weapon.current.position.set(curP.riflePX, curP.riflePY, curP.riflePZ)
      R.weapon.current.rotation.set(curP.rifleRX, curP.rifleRY, curP.rifleRZ)
      R.weapon.current.scale.setScalar(Math.max(0.001, curP.rifleVis))
    }
    if (R.ruana.current) R.ruana.current.rotation.set(curP.ruanaX, 0, curP.ruanaZ)
    if (R.pack.current) R.pack.current.rotation.x = curP.packX
    if (R.medkit.current) {
      R.medkit.current.scale.setScalar(Math.max(0.001, curP.medkit))
      R.medkit.current.position.y = 0.2 + Math.sin(t * 2.4) * 0.012
    }

    /* Polvo del derrape (pool fijo, sin asignaciones en bucle) */
    const sliding = act === 'slide'
    for (let i = 0; i < 8; i++) {
      const m = R.dust.current[i]
      if (!m) continue
      if (!sliding) { m.visible = false; continue }
      const u = (t * 1.7 + i * 0.125) % 1
      m.visible = true
      m.position.set(
        Math.sin(i * 2.4) * 0.34 - 0.1,
        0.04 + u * 0.4,
        -0.25 - u * 1.0 - (i % 3) * 0.15,
      )
      m.scale.setScalar(0.16 + u * 0.55)
      ;(m.material as THREE.MeshBasicMaterial).opacity = (1 - u) * 0.45
    }
    /* Chispas verdes de curación (pool fijo) */
    const healing = act === 'heal'
    for (let i = 0; i < 10; i++) {
      const m = R.spark.current[i]
      if (!m) continue
      if (!healing) { m.visible = false; continue }
      const u = (t * 0.55 + i * 0.1) % 1
      m.visible = true
      m.position.set(
        Math.sin(t * 1.6 + i * 1.9) * 0.13,
        0.22 + u * 0.5,
        0.42 + Math.cos(t * 1.4 + i * 2.3) * 0.13,
      )
      m.scale.setScalar(0.02 * (1 - u * 0.6))
      ;(m.material as THREE.MeshBasicMaterial).opacity = (1 - u) * 0.95
    }
  })

  /* ---------------- geometría del brazo ---------------- */
  const arm = (side: 1 | -1) => (
    <group
      name={side > 0 ? 'hombro derecho' : 'hombro izquierdo'}
      ref={side > 0 ? R.shR : R.shL}
      position={[side * 0.25, 0.38, 0]}
    >
      <T name="deltoides" geo={<sphereGeometry args={[0.077, 14, 12]} />} s={[1, 1.05, 1]} c={CREAM} />
      <T geo={<capsuleGeometry args={[0.056, 0.19, 4, 12]} />} p={[0, -0.15, 0]} c={CREAM} />
      <T geo={<cylinderGeometry args={[0.058, 0.058, 0.035, 12]} />} p={[0, -0.1, 0]} c="#1e1e1e" />
      <group name={side > 0 ? 'codo derecho' : 'codo izquierdo'} ref={side > 0 ? R.elR : R.elL} position={[0, -0.3, 0]}>
        <T geo={<sphereGeometry args={[0.055, 12, 10]} />} c={CREAM} />
        <T geo={<capsuleGeometry args={[0.048, 0.24, 4, 12]} />} p={[0, -0.16, 0]} c={CREAM} />
        <T geo={<cylinderGeometry args={[0.05, 0.05, 0.03, 12]} />} p={[0, -0.1, 0]} c="#1e1e1e" />
        <group name={side > 0 ? 'mano derecha' : 'mano izquierda'} ref={side > 0 ? R.haR : R.haL} position={[0, -0.3, 0]}>
          <T geo={<boxGeometry args={[0.075, 0.09, 0.052]} />} p={[0, -0.04, 0.004]} c={SKIN} />
          {[0, 1, 2, 3].map((f) => (
            <T key={f} geo={<boxGeometry args={[0.015, 0.062, 0.026]} />} p={[-0.026 + f * 0.0175, -0.105, 0.016]} r={[0.55, 0, 0]} c={SKIN} />
          ))}
          <T geo={<boxGeometry args={[0.02, 0.05, 0.03]} />} p={[side * -0.04, -0.06, 0.035]} r={[0.4, 0, side * -0.6]} c={SKIN} />
          <T geo={<boxGeometry args={[0.07, 0.02, 0.05]} />} p={[0, 0.01, 0.004]} c={SKIN} />
        </group>
      </group>
    </group>
  )

  const leg = (side: 1 | -1) => (
    <group name={side > 0 ? 'pierna derecha' : 'pierna izquierda'} ref={side > 0 ? R.hipR : R.hipL} position={[side * 0.11, -0.06, 0]}>
      <T geo={<sphereGeometry args={[0.1, 14, 12]} />} s={[1, 1.1, 1]} c={TROUSER} />
      <T geo={<capsuleGeometry args={[0.085, 0.24, 4, 14]} />} p={[0, -0.2, 0]} c={TROUSER} />
      <group name={side > 0 ? 'rodilla derecha' : 'rodilla izquierda'} ref={side > 0 ? R.kneeR : R.kneeL} position={[0, -0.44, 0]}>
        <T geo={<sphereGeometry args={[0.078, 12, 10]} />} p={[0, 0.01, 0.01]} c={TROUSER} />
        <T geo={<capsuleGeometry args={[0.068, 0.22, 4, 12]} />} p={[0, -0.18, 0]} c={TROUSER} />
        <T geo={<cylinderGeometry args={[0.07, 0.072, 0.06, 12]} />} p={[0, -0.3, 0]} c={BOOT} />
        <group name={side > 0 ? 'tobillo derecho' : 'tobillo izquierdo'} ref={side > 0 ? R.ankR : R.ankL} position={[0, -0.34, 0]}>
          <T geo={<boxGeometry args={[0.135, 0.15, 0.16]} />} p={[0, -0.05, 0.01]} c={BOOT} />
          <T geo={<boxGeometry args={[0.13, 0.1, 0.19]} />} p={[0, -0.075, 0.1]} c={BOOT} />
          <T geo={<boxGeometry args={[0.13, 0.02, 0.05]} />} p={[0, -0.045, 0.17]} c="#2e1c0e" />
          <T geo={<boxGeometry args={[0.145, 0.035, 0.36]} />} p={[0, -0.128, 0.045]} c="#22150c" />
          {[0, 1, 2].map((i) => (
            <T key={i} geo={<boxGeometry args={[0.147, 0.012, 0.03]} />} p={[0, -0.11, -0.05 + i * 0.09]} c="#18100a" />
          ))}
          <T geo={<boxGeometry args={[0.02, 0.05, 0.12]} />} p={[side * 0.075, -0.07, 0.02]} c="#2e1c0e" />
        </group>
      </group>
    </group>
  )

  return (
    <group name="personaje">
      {/* ============ CADERA ============ */}
      <group ref={R.hips} name="cadera" position={[0, 0.98, 0]}>
        <T geo={<sphereGeometry args={[0.135, 16, 12]} />} s={[1.1, 0.8, 0.9]} c={TROUSER} />
        <T geo={<cylinderGeometry args={[0.145, 0.14, 0.075, 18]} />} p={[0, 0.04, 0]} c="#2c2118" />
        <T geo={<boxGeometry args={[0.075, 0.05, 0.02]} />} p={[0, 0.04, 0.145]} c="#c9a24a" emissive="#7a5a1a" emissiveIntensity={0.15} />

        {/* ============ TORSO / ESPINA ============ */}
        <group ref={R.spine} name="columna" position={[0, 0.1, 0]}>
          <group ref={R.chest} name="pecho">
            <T geo={<capsuleGeometry args={[0.155, 0.3, 4, 16]} />} p={[0, 0.17, 0]} s={[1.28, 1, 0.78]} c={CREAM} />
            <T geo={<cylinderGeometry args={[0.115, 0.14, 0.16, 16]} />} p={[0, 0.0, 0]} s={[1.2, 1, 0.85]} c={CREAM} />
          </group>

          {/* ---- RUANA con aperturas laterales ---- */}
          <group ref={R.ruana} name="ruana">
            <T
              name="ruana frente"
              geo={<cylinderGeometry args={[0.27, 0.4, 0.76, 20, 1, true, -Math.PI / 2 + 0.34, Math.PI - 0.68]} />}
              p={[0, 0.05, 0]}
              s={[1.1, 1, 0.74]}
              map={ruanaTex}
              c="#f6f3ea"
              cast
            />
            <T
              name="ruana espalda"
              geo={<cylinderGeometry args={[0.27, 0.4, 0.76, 20, 1, true, Math.PI / 2 + 0.34, Math.PI - 0.68]} />}
              p={[0, 0.05, 0]}
              s={[1.1, 1, 0.74]}
              map={ruanaTex}
              c="#f6f3ea"
              cast
            />
            <T name="canesú" geo={<cylinderGeometry args={[0.235, 0.275, 0.14, 20, 1, true]} />} p={[0, 0.4, 0]} s={[1.1, 1, 0.74]} map={ruanaTex} c="#f6f3ea" />
            <T name="flecos" geometry={fringe} c="#efe9db" />
          </group>

          {/* ---- MOCHILA TÁCTICA ---- */}
          <group ref={R.pack} name="mochila" position={[0, 0.16, -0.27]}>
            <T geo={<boxGeometry args={[0.4, 0.5, 0.21]} />} p={[0, 0, 0]} c="#4b5320" />
            <T geo={<sphereGeometry args={[0.1, 12, 10]} />} p={[0, 0.2, 0]} s={[1.9, 0.7, 1]} c="#4b5320" />
            <T geo={<boxGeometry args={[0.38, 0.17, 0.24]} />} p={[0, 0.3, -0.01]} c="#556b2f" />
            <T geo={<boxGeometry args={[0.36, 0.05, 0.245]} />} p={[0, 0.37, -0.01]} c="#3d4419" />
            {[-1, 1].map((sx) => (
              <group key={sx}>
                <T geo={<boxGeometry args={[0.05, 0.2, 0.026]} />} p={[sx * 0.1, 0.3, 0.125]} c={STRAP} />
                <T geo={<boxGeometry args={[0.045, 0.05, 0.03]} />} p={[sx * 0.1, 0.2, 0.13]} c="#111" />
                <T geo={<boxGeometry args={[0.035, 0.03, 0.026]} />} p={[sx * 0.1, 0.1, 0.13]} c="#8d9299" />
              </group>
            ))}
            {[-1, 1].map((sx) => (
              <group key={`side${sx}`}>
                <T geo={<boxGeometry args={[0.1, 0.24, 0.16]} />} p={[sx * 0.24, -0.06, 0]} c="#556b2f" />
                <T geo={<boxGeometry args={[0.105, 0.08, 0.17]} />} p={[sx * 0.24, 0.08, 0]} c="#454f1c" />
                <T geo={<boxGeometry args={[0.03, 0.16, 0.02]} />} p={[sx * 0.29, -0.02, 0.02]} c={STRAP} />
              </group>
            ))}
            <T geo={<boxGeometry args={[0.3, 0.2, 0.06]} />} p={[0, -0.14, -0.13]} c="#3d4419" />
            <T geo={<boxGeometry args={[0.16, 0.1, 0.03]} />} p={[0, 0.06, -0.115]} c={STRAP} />
            <T geo={<cylinderGeometry args={[0.06, 0.06, 0.34, 12]} />} p={[0, 0.42, -0.03]} r={[0, 0, Math.PI / 2]} c="#c9b48a" />
            {[-1, 1].map((sx) => (
              <T key={`strap${sx}`} geo={<boxGeometry args={[0.07, 0.34, 0.035]} />} p={[sx * 0.13, 0.3, 0.1]} r={[-0.3, 0, sx * 0.06]} c={STRAP} />
            ))}
            <T geo={<boxGeometry args={[0.2, 0.06, 0.05]} />} p={[0, -0.3, -0.02]} c={STRAP} />
          </group>

          {/* ---- ARMA MONTADA EN EL TORSO ---- */}
          <group ref={R.weapon} name="montura del arma">
            <AK47 variant={firing ? 1 : 0} />
          </group>

          {/* ---- BOTIQUÍN EN MANOS (curación) ---- */}
          <group ref={R.medkit} name="botiquín en mano" position={[0, 0.2, 0.42]} scale={0.001}>
            <T geo={<boxGeometry args={[0.2, 0.13, 0.1]} />} c="#f2f4f4" />
            <T geo={<boxGeometry args={[0.035, 0.012, 0.104]} />} p={[0, 0.005, 0]} c="#e02b2b" />
            <T geo={<boxGeometry args={[0.1, 0.012, 0.035]} />} p={[0, 0.005, 0]} c="#e02b2b" />
            <T geo={<boxGeometry args={[0.204, 0.03, 0.03]} />} p={[0, 0.03, 0]} c="#2b2f33" />
            <T geo={<boxGeometry args={[0.06, 0.03, 0.02]} />} p={[0, 0.075, 0]} c="#2b2f33" />
          </group>

          {/* ---- BRAZOS ---- */}
          {arm(-1)}
          {arm(1)}

          {/* ---- CUELLO / CABEZA ---- */}
          <group ref={R.neck} name="cuello" position={[0, 0.44, 0]}>
            <T geo={<cylinderGeometry args={[0.055, 0.065, 0.12, 14]} />} p={[0, 0.04, 0]} c={SKIN} />
            <group ref={R.head} name="cabeza" position={[0, 0.1, 0]}>
              <T name="cráneo" geo={<sphereGeometry args={[0.117, 20, 16]} />} p={[0, 0.06, 0]} s={[0.92, 1.06, 1]} c={SKIN} />
              <T name="mandíbula" geo={<sphereGeometry args={[0.082, 16, 12]} />} p={[0, 0.005, 0.025]} s={[0.92, 0.78, 1]} c={SKIN} />
              <T name="cabello" geo={<sphereGeometry args={[0.119, 18, 14, 0, Math.PI * 2, 0, Math.PI / 2]} />} p={[0, 0.058, -0.006]} s={[0.94, 1.05, 1.02]} c="#241812" />
              <T name="patillas" geo={<boxGeometry args={[0.02, 0.07, 0.09]} />} p={[0.093, 0.02, -0.02]} c="#241812" />
              <T name="patilla izq" geo={<boxGeometry args={[0.02, 0.07, 0.09]} />} p={[-0.093, 0.02, -0.02]} c="#241812" />
              <T name="barba" geo={<sphereGeometry args={[0.078, 14, 10]} />} p={[0, -0.012, 0.05]} s={[0.9, 0.6, 0.75]} c="#2b1d14" />
              <T geo={<boxGeometry args={[0.055, 0.014, 0.014]} />} p={[0, -0.028, 0.1]} c="#1d140e" />
              {[-1, 1].map((sx) => (
                <group key={sx}>
                  <T geo={<boxGeometry args={[0.046, 0.013, 0.016]} />} p={[sx * 0.046, 0.086, 0.094]} r={[0, 0, sx * 0.14]} c="#241812" />
                  <T geo={<sphereGeometry args={[0.022, 12, 10]} />} p={[sx * 0.048, 0.058, 0.086]} s={[1, 0.88, 0.6]} c="#f7f4ee" />
                  <T geo={<sphereGeometry args={[0.0115, 10, 8]} />} p={[sx * 0.05, 0.058, 0.1]} c="#20160f" />
                  <T geo={<sphereGeometry args={[0.004, 6, 6]} />} p={[sx * 0.054, 0.062, 0.106]} c="#ffffff" />
                  <T geo={<sphereGeometry args={[0.028, 10, 8]} />} p={[sx * 0.108, 0.045, -0.005]} s={[0.4, 1, 1]} c={SKIN} />
                </group>
              ))}
              <T name="nariz" geo={<sphereGeometry args={[0.03, 12, 10]} />} p={[0, 0.032, 0.108]} s={[0.75, 1.05, 1.25]} c={SKIN} />
              <T geo={<sphereGeometry args={[0.012, 8, 8]} />} p={[0.016, 0.016, 0.116]} c="#8a5c3c" />
              <T geo={<sphereGeometry args={[0.012, 8, 8]} />} p={[-0.016, 0.016, 0.116]} c="#8a5c3c" />

              {/* ---- SOMBRERO VUETTIAO ---- */}
              <group name="sombrero vueltiao" position={[0, 0.112, 0]} rotation={[0.07, 0, 0.035]}>
                <T name="ala" geometry={hatBrimGeo} map={hatBrim} c="#efe6cc" />
                <T name="corona" geometry={hatCrownGeo} map={hatBand} c="#f0e8d2" />
                <T name="cinta" geo={<cylinderGeometry args={[0.179, 0.177, 0.05, 36, 1, true]} />} p={[0, 0.032, 0]} c="#151515" />
              </group>
            </group>
          </group>
        </group>

        {/* ---- PIERNAS ---- */}
        {leg(-1)}
        {leg(1)}
      </group>

      {/* ============ PARTÍCULAS (pools fijos) ============ */}
      <group name="polvo de derrape" position={[0, 0, 0]}>
        {Array.from({ length: 8 }).map((_, i) => (
          <mesh key={i} ref={(el) => { R.dust.current[i] = el }} visible={false} userData={{ noCap: true }} castShadow={false}>
            <sphereGeometry args={[1, 8, 6]} />
            <meshBasicMaterial color="#cbbd9a" transparent opacity={0.4} depthWrite={false} />
          </mesh>
        ))}
      </group>
      <group name="chispas de curación">
        {Array.from({ length: 10 }).map((_, i) => (
          <mesh key={i} ref={(el) => { R.spark.current[i] = el }} visible={false} userData={{ noCap: true }} castShadow={false}>
            <sphereGeometry args={[1, 6, 5]} />
            <meshBasicMaterial color="#6dff9a" transparent opacity={0.9} depthWrite={false} blending={THREE.AdditiveBlending} />
          </mesh>
        ))}
      </group>
    </group>
  )
}
