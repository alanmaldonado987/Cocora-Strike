import * as THREE from 'three'
import { useMemo, useRef } from 'react'
import { Geo, GeoBuilder, TEX, rng, rockGeometry, useAnim, useDispose } from '../helpers'
import { WaxPalm } from './WaxPalm'
import { ColonialHouse } from './ColonialHouse'
import { Helicopter } from './Helicopter'
import { Character } from './Character'
import { StoneBridge } from './StoneBridge'
import { Condor, Tapir } from './Fauna'
import { CoffeeBush, Fence, Medkit, CocoraSign } from './Props'

const SIZE = 72, SEG = 110

export function riverX(z: number) { return 13 + 3 * Math.sin(z * 0.11) + 1.2 * Math.sin(z * 0.31) }
function pathX(z: number) { return -2 + 2.5 * Math.sin(z * 0.09 + 1) }
function baseHills(x: number, z: number) {
  let h = 0.6 + 1.2 * Math.sin(x * 0.11 + 0.5) * Math.cos(z * 0.09) + 0.6 * Math.sin(x * 0.27 + 2) * Math.sin(z * 0.23 + 1)
  h += 5.5 * Math.exp(-((x + 10) ** 2 + (z + 26) ** 2) / 260)
  h += 6.5 * Math.exp(-((x - 20) ** 2 + (z + 28) ** 2) / 300)
  h += 3.5 * Math.exp(-((x + 30) ** 2 + (z - 2) ** 2) / 200)
  h += 2.5 * Math.exp(-((x - 30) ** 2 + (z - 10) ** 2) / 160)
  h += Math.max(0, -z - 10) * 0.12
  return h
}
export function terrainHeight(x: number, z: number) {
  const dx = x - riverX(z)
  const riverMask = Math.exp(-(dx * dx) / 36)
  let h = baseHills(x, z) * (1 - riverMask * 0.9)
  h -= 2.4 * Math.exp(-(dx * dx) / 7)
  const cd2 = (x + 6) ** 2 + (z - 4) ** 2
  h -= 0.9 * Math.exp(-cd2 / 5) - 0.22 * Math.exp(-cd2 / 14)
  const vill = Math.exp(-((x + 14) ** 2 + (z + 2) ** 2) / 90)
  h = h * (1 - vill * 0.6) + vill * 0.6 * 0.6
  return h
}

function buildTerrain() {
  const geo = new THREE.PlaneGeometry(SIZE, SIZE, SEG, SEG)
  geo.rotateX(-Math.PI / 2)
  const pos = geo.attributes.position
  const colors = new Float32Array(pos.count * 3)
  const grassD = new THREE.Color('#4f9a33'), grassL = new THREE.Color('#8ed05a'), sand = new THREE.Color('#c9b78a')
  const bed = new THREE.Color('#6d6a5a'), dirt = new THREE.Color('#9a7a52'), scorch = new THREE.Color('#2f2a26'), rockC = new THREE.Color('#7f8a6a')
  const c = new THREE.Color()
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), z = pos.getZ(i)
    const h = terrainHeight(x, z)
    pos.setY(i, h)
    const n = 0.5 + 0.5 * Math.sin(x * 0.9 + Math.sin(z * 0.7) * 2) * Math.cos(z * 0.8 + Math.sin(x * 0.5))
    c.copy(grassD).lerp(grassL, THREE.MathUtils.clamp(n * 0.7 + h * 0.05, 0, 1))
    if (h > 4.5) c.lerp(rockC, THREE.MathUtils.clamp((h - 4.5) / 3, 0, 0.6))
    const dx = Math.abs(x - riverX(z))
    if (dx < 4) c.lerp(sand, THREE.MathUtils.smoothstep(4 - dx, 0, 1.3))
    if (dx < 2.4) c.lerp(bed, THREE.MathUtils.smoothstep(2.4 - dx, 0, 1))
    const dp = Math.abs(x - pathX(z))
    if (dp < 1.6 && z > -16) c.lerp(dirt, THREE.MathUtils.smoothstep(1.6 - dp, 0, 0.9))
    const cd = Math.hypot(x + 6, z - 4)
    if (cd < 3.4) c.lerp(scorch, THREE.MathUtils.smoothstep(3.4 - cd, 0, 1.6))
    colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b
  }
  geo.setAttribute('color', new THREE.BufferAttribute(colors, 3))
  geo.computeVertexNormals()
  return geo
}

function buildTrees() {
  const r = rng(99)
  const trunks = new GeoBuilder(), canopies = new GeoBuilder()
  const trunk = new THREE.CylinderGeometry(0.18, 0.28, 2.2, 7); trunk.translate(0, 1.1, 0)
  const ball = new THREE.SphereGeometry(1, 9, 7)
  let placed = 0, tries = 0
  while (placed < 42 && tries < 400) {
    tries++
    const x = (r() - 0.5) * SIZE * 0.95, z = -SIZE / 2 + r() * SIZE * 0.95
    const back = z < -14 || Math.abs(x) > 23
    if (!back) continue
    if (Math.abs(x - riverX(z)) < 5) continue
    const h = terrainHeight(x, z)
    const s = 0.8 + r() * 0.8
    trunks.add(trunk, [x, h - 0.2, z], [0, 0, 0], s)
    for (let k = 0; k < 3; k++) {
      canopies.add(ball, [x + (r() - 0.5) * 1.6 * s, h + 2.4 * s + (r() - 0.3) * 1.2 * s, z + (r() - 0.5) * 1.6 * s], [0, 0, 0], (1.1 + r() * 0.8) * s)
    }
    placed++
  }
  trunk.dispose(); ball.dispose()
  return { trunks: trunks.build(), canopies: canopies.build() }
}

function buildRocks() {
  const r = rng(7)
  const b = new GeoBuilder()
  const spots: [number, number, number][] = [[6, 6, 0.9], [-4.5, 7.5, 0.7], [15.5, 12, 1.2], [17, -5, 1.0], [9.5, 10.5, 0.6], [-9, -7, 1.1], [24, 4, 1.4], [-20, 12, 1.0]]
  spots.forEach(([x, z, s], i) => {
    const g = rockGeometry(200 + i, s, 2, 0.7)
    b.add(g, [x, terrainHeight(x, z) + s * 0.2, z], [0, r() * 3, 0])
    g.dispose()
  })
  return b.build()
}

const PALMS: [number, number, number, number][] = (() => {
  const r = rng(5)
  const out: [number, number, number, number][] = []
  let tries = 0
  while (out.length < 26 && tries < 500) {
    tries++
    const x = (r() - 0.5) * 60, z = -32 + r() * 42
    if (Math.abs(x - riverX(z)) < 4.5) continue
    if (Math.hypot(x + 14, z + 2) < 9) continue
    if (Math.hypot(x + 3, z + 2) < 7) continue
    if (Math.hypot(x - 3, z - 8) < 6) continue
    if (z > 8 && Math.abs(x) < 10) continue
    if (out.some(([px, , pz]) => Math.hypot(px - x, pz - z) < 4)) continue
    out.push([x, z, 11 + r() * 7, Math.floor(r() * 4)])
  }
  return out
})()

export function FullScene() {
  const terrain = useMemo(() => buildTerrain(), [])
  const trees = useMemo(() => buildTrees(), [])
  const rocks = useMemo(() => buildRocks(), [])
  useDispose(terrain, trees.trunks, trees.canopies, rocks)
  const water = useMemo(() => TEX.water(), [])
  const waterRef = useRef<THREE.Mesh>(null)
  const fly = useRef<THREE.Group>(null)
  useAnim((t, dt) => {
    const m = waterRef.current?.material as THREE.MeshStandardMaterial | undefined
    if (m?.map) m.map.offset.y -= dt * 0.03
    if (fly.current) {
      const a = t * 0.22
      fly.current.position.set(2 + Math.cos(a) * 13, 14 + Math.sin(t * 0.5) * 1.5, -8 + Math.sin(a) * 13)
      fly.current.rotation.set(0, -a, 0.3)
    }
  })
  const at = (x: number, z: number, dy = 0): [number, number, number] => [x, terrainHeight(x, z) + dy, z]
  return (
    <group>
      <mesh name="terreno" geometry={terrain} receiveShadow castShadow userData={{ noCap: true }}>
        <meshStandardMaterial vertexColors roughness={1} />
      </mesh>
      <mesh ref={waterRef} name="agua" position={[0, -1.0, 0]} rotation={[-Math.PI / 2, 0, 0]} userData={{ noCap: true }}>
        <planeGeometry args={[SIZE, SIZE]} />
        <meshStandardMaterial map={water} color="#5fb7ea" transparent opacity={0.88} roughness={0.12} metalness={0.1} />
      </mesh>
      <Geo name="troncos" geometry={trees.trunks} c="#5a4028" m={{ roughness: 0.95 }} />
      <Geo name="copas" geometry={trees.canopies} c="#2f7a2e" m={{ roughness: 0.9 }} />
      <Geo name="rocas" geometry={rocks} m={{ vertexColors: true, flatShading: true, roughness: 0.95 }} />

      <group name="pueblo">
        <group position={at(-16, -4, -0.1)} rotation={[0, 0.35, 0]}><ColonialHouse variant={0} /></group>
        <group position={at(-11.5, -11, -0.1)} rotation={[0, -0.25, 0]}><ColonialHouse variant={0} /></group>
        <group position={at(-19, 4.5, -0.1)} rotation={[0, 1.0, 0]}><ColonialHouse variant={1} /></group>
      </group>

      <group name="letrero" position={at(-4, -17, 0.6)} rotation={[0, 0.15, 0]} scale={1.15}>
        <CocoraSign variant={0} />
      </group>

      <group name="helicóptero" position={at(-3, -2, 0)} rotation={[0, 0.7, 0]}>
        <Helicopter variant={0} />
      </group>

      <group name="personaje" position={at(3, 7, 0)} rotation={[0, -0.6, 0]}>
        <Character variant={0} />
      </group>
      <group name="botiquín" position={at(0.4, 8.5, 0)}>
        <Medkit variant={0} />
      </group>

      <group name="cerca" position={at(1, 10.5, 0)} rotation={[0, 0.05, 0]}>
        <Fence variant={1} />
      </group>
      <group name="cafetales">
        <group position={at(-8, 8, 0)}><CoffeeBush variant={1} seed={1} /></group>
        <group position={at(-10, 11, 0)} rotation={[0, 1.2, 0]}><CoffeeBush variant={1} seed={2} /></group>
        <group position={at(6.5, 10, 0)} rotation={[0, 2.2, 0]}><CoffeeBush variant={0} seed={0} /></group>
      </group>

      <group name="puente" position={[riverX(2), -1.9, 2]}>
        <StoneBridge variant={0} />
      </group>

      <group name="danta" position={at(8.5, -4, 0)} rotation={[0, 2.4, 0]}>
        <Tapir variant={0} />
      </group>

      <group name="cóndor">
        <group ref={fly}>
          <Condor variant={0} flying={false} />
        </group>
      </group>

      <group name="palmas de cera">
        {PALMS.map(([x, z, h, seed], i) => (
          <group key={i} position={at(x, z, -0.2)} rotation={[0, seed * 1.3, 0]}>
            <WaxPalm height={h} seed={seed} />
          </group>
        ))}
      </group>
    </group>
  )
}
